PSulit Leave Request — Supabase-retained update

This package retains Supabase as the source of truth and adds an approved-only Google Sheets mirror.
See SUPABASE-GOOGLE-SHEETS-SETUP.md before deployment.

No live Netlify, Supabase, Telegram webhook, Payroll, or Google Apps Script configuration
has been changed by generating this ZIP.
