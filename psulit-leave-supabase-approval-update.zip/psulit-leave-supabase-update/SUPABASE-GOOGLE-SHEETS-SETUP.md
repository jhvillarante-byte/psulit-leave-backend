# PSulit Leave Request — Supabase + Google Sheets

## Architecture
- Supabase (`leave_requests`) remains the source of truth for pending, approved and declined requests.
- Jen's private Telegram chat is the only approval channel.
- Only approved requests are mirrored to the Google Sheet `LEAVE` tab and announced to the staff Telegram group.
- The Netlify function also attempts the existing Payroll Supabase `leave_records` insert. Confirm the Payroll table schema and test leave-credit calculations before staff rollout.

## 1. Supabase
Run `supabase-setup.sql` in the Leave App Supabase project's SQL Editor. For an existing table, the script adds the approval audit columns safely.

Set Netlify environment variables:
- `SUPABASE_URL`
- `SUPABASE_SECRET_KEY` (server-side secret/service role key; never put this in browser code)
- `BOT_TOKEN`
- `JEN_CHAT_ID` (Jen's private Telegram chat ID)
- `GROUP_CHAT_ID` (staff group chat ID)

For payroll deduction integration, also set:
- `PAYROLL_SUPABASE_URL`
- `PAYROLL_SUPABASE_SECRET_KEY`

The Payroll integration must be checked against the actual `leave_records` schema. This version inserts approved leave rows but does not assume a unique request-id column exists in Payroll.

## 2. Google Sheets mirror (approved requests only)
Open the supplied spreadsheet and choose **Extensions → Apps Script**.
Replace the Apps Script editor contents with `google-apps-script/Code.gs`.

In Apps Script **Project Settings → Script Properties**, add:
- `LEAVE_SYNC_SECRET` = a long random secret (at least 32 characters)

Run `initializeLeaveSheets` once and authorize it. It initializes the visible `LEAVE` tab and hidden `_LEAVE_REQUESTS` tab. The visible `LEAVE` tab receives approved rows only.

Deploy as a **Web app**:
- Execute as: **Me**
- Who has access: **Anyone** (the shared secret authenticates requests)
- Copy the `/exec` URL.

Add these Netlify environment variables:
- `GOOGLE_SHEETS_SYNC_URL` = Apps Script `/exec` URL
- `GOOGLE_SHEETS_SYNC_SECRET` = exactly the same secret as `LEAVE_SYNC_SECRET`

## 3. Telegram webhook
After deploying the Netlify site, set the bot webhook to:
`https://YOUR-NETLIFY-SITE.netlify.app/api/telegram-webhook`

Use your actual Netlify site URL.

## 4. Important checks before rollout
1. Confirm the approver chat ID in `JEN_CHAT_ID` is yours.
2. Confirm the Telegram bot can message the approver privately, employees and the staff group.
3. Confirm the Supabase table is reachable with the server-side key.
4. Confirm the Payroll `leave_records` schema and that a single approved request deducts credits correctly. Do not run a real payroll deduction test with a live employee; use a test employee/request first.
5. Test a pending request: it must not appear in the `LEAVE` tab or staff group.
6. Approve a test request: it should appear once in the `LEAVE` tab and staff group.
7. Decline a test request: it must not appear in the `LEAVE` tab or staff group.
8. Verify that repeating an approval callback does not process the request a second time.

## Security
Keep all Supabase secret/service-role keys, Telegram bot tokens and sync secrets in Netlify environment variables or Apps Script Script Properties. Never place them in `index.html`.
