// netlify/functions/submit-time-request.js
//
// Called by kiosk.html when the employee taps "Confirm". Instead of writing
// straight to time_logs, this marks the request as awaiting approval and
// sends the supervisor a Telegram message with Approve/Decline buttons.
//
// Required Netlify environment variables:
//   SUPABASE_URL              e.g. https://mxnsyvqizabiqnrqiwpx.supabase.co
//   SUPABASE_SERVICE_ROLE_KEY the service role key (Settings > API in Supabase) - NOT the publishable key
//   TELEGRAM_BOT_TOKEN        the bot token used for Leave Request approvals
//   SUPERVISOR_CHAT_ID        your Telegram chat id

exports.handler = async function (event) {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }

  let token, note;
  try {
    const body = JSON.parse(event.body || '{}');
    token = body.token;
    note = (body.note || '').trim();
    if (!token) throw new Error('Missing token');
  } catch (err) {
    return { statusCode: 400, body: JSON.stringify({ error: 'Missing or invalid token' }) };
  }

  const SUPABASE_URL = process.env.SUPABASE_URL;
  const SERVICE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
  const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
  const SUPERVISOR_CHAT_ID = process.env.SUPERVISOR_CHAT_ID;

  try {
    // Call submit_kiosk_request via Supabase's RPC REST endpoint
    const rpcResp = await fetch(`${SUPABASE_URL}/rest/v1/rpc/submit_kiosk_request`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'apikey': SERVICE_KEY,
        'Authorization': `Bearer ${SERVICE_KEY}`
      },
      body: JSON.stringify({ input_token: token, input_note: note || null })
    });

    if (!rpcResp.ok) {
      const errText = await rpcResp.text();
      throw new Error(errText || 'Could not submit request');
    }

    const rows = await rpcResp.json();
    const row = Array.isArray(rows) ? rows[0] : rows;
    if (!row) throw new Error('No response from submit_kiosk_request');

    const { employee_name, action, requested_at, note: returnedNote } = row;
    const when = new Date(requested_at).toLocaleString('en-PH', {
      month: 'long', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit'
    });
    const actionLabel = action === 'in' ? 'time in' : 'time out';
    const noteLine = returnedNote ? `\nReason: ${returnedNote}` : '';

    const message =
      `\u23F0 *Time ${action === 'in' ? 'In' : 'Out'} Request*\n\n` +
      `${employee_name} wants to ${actionLabel}\n` +
      `Requested at: ${when}${noteLine}`;

    const tgResp = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: SUPERVISOR_CHAT_ID,
        text: message,
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [[
            { text: '\u2705 Approve', callback_data: `approve:${token}` },
            { text: '\u274C Decline', callback_data: `decline:${token}` }
          ]]
        }
      })
    });

    if (!tgResp.ok) {
      const errText = await tgResp.text();
      console.error('Telegram send failed:', errText);
      // Request is still submitted even if the Telegram message failed to send -
      // don't block the employee's flow, but log this so it can be checked.
    }

    return {
      statusCode: 200,
      body: JSON.stringify({ status: 'submitted', employee_name, action })
    };
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
  }
};
