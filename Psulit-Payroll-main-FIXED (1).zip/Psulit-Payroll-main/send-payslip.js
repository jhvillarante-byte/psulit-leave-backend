// netlify/functions/send-payslip.js
//
// Sends a payslip PDF as a Telegram document message using the Telegram Bot API.
// Builds the multipart/form-data request manually with Buffers only (no FormData/Blob),
// since those globals aren't reliably available across all Netlify Functions runtimes.
//
// Setup: in the Netlify site dashboard, go to
// Site configuration > Environment variables > Add a variable
// Key:   TELEGRAM_BOT_TOKEN
// Value: (the token @BotFather gave you when you created the bot, looks like
//         123456789:AAExampleTokenStringHere)
//
// Each employee needs to have messaged your bot at least once (Telegram
// requires this before a bot can message someone) -- see SETUP_INSTRUCTIONS.md
// for how to find their numeric Chat ID afterward.

exports.handler = async function (event) {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: JSON.stringify({ error: 'Method not allowed' }) };
  }

  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'TELEGRAM_BOT_TOKEN is not set on the server. Add it under Site configuration > Environment variables in Netlify, then redeploy.' })
    };
  }

  let chatId, filename, pdfBase64, message;
  try {
    const parsed = JSON.parse(event.body || '{}');
    chatId = parsed.chatId;
    filename = parsed.filename;
    pdfBase64 = parsed.pdfBase64;
    message = parsed.message;
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: '[parse-body] ' + err.message }) };
  }

  if (!chatId || !pdfBase64) {
    return { statusCode: 500, body: JSON.stringify({ error: '[validate] Missing chatId or pdfBase64 in request body.' }) };
  }
  // Chat IDs should be plain numeric strings (Telegram user/chat IDs). Strip anything else defensively.
  chatId = String(chatId).trim();
  if (!/^-?\d+$/.test(chatId)) {
    return { statusCode: 500, body: JSON.stringify({ error: '[validate] Chat ID "' + chatId + '" is not a plain number. Re-check the value copied from getUpdates.' }) };
  }

  let fileBuffer;
  try {
    fileBuffer = Buffer.from(pdfBase64, 'base64');
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: '[decode-pdf] ' + err.message }) };
  }

  const safeFilename = (filename || 'payslip.pdf').replace(/[^a-zA-Z0-9._-]/g, '_');
  const safeMessage = message ? String(message).replace(/[\r\n]+/g, ' ') : '';

  let body, boundary;
  try {
    boundary = 'NetlifyFormBoundary' + Math.random().toString(16).slice(2);
    const CRLF = '\r\n';
    const parts = [];
    parts.push(Buffer.from(
      '--' + boundary + CRLF + 'Content-Disposition: form-data; name="chat_id"' + CRLF + CRLF + chatId + CRLF
    ));
    if (safeMessage) {
      parts.push(Buffer.from(
        '--' + boundary + CRLF + 'Content-Disposition: form-data; name="caption"' + CRLF + CRLF + safeMessage + CRLF
      ));
    }
    parts.push(Buffer.from(
      '--' + boundary + CRLF + 'Content-Disposition: form-data; name="document"; filename="' + safeFilename + '"' + CRLF + 'Content-Type: application/pdf' + CRLF + CRLF
    ));
    parts.push(fileBuffer);
    parts.push(Buffer.from(CRLF + '--' + boundary + '--' + CRLF));
    body = Buffer.concat(parts);
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: '[build-multipart] ' + err.message }) };
  }

  let resp, text;
  try {
    resp = await fetch('https://api.telegram.org/bot' + token + '/sendDocument', {
      method: 'POST',
      headers: {
        'Content-Type': 'multipart/form-data; boundary=' + boundary,
        'Content-Length': String(body.length)
      },
      body
    });
    text = await resp.text();
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: '[fetch-telegram] ' + err.message }) };
  }

  let data;
  try { data = JSON.parse(text); } catch (e) { data = null; }

  if (!data || !data.ok) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: '[telegram-api] ' + (data && data.description ? data.description : text.slice(0, 300)) })
    };
  }

  return {
    statusCode: 200,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ ok: true })
  };
};
