// Authenticated bridge from the Payroll owner to the Google Sheets ledger.
// Netlify environment variables required: SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY,
// GOOGLE_SHEETS_SYNC_URL, GOOGLE_SHEETS_SYNC_SECRET.
const OWNER_EMAIL = 'jhvillarante@gmail.com';
const ALLOWED_SHEETS = new Set(['PAYROLL', 'EMPLOYEE CREDITS', 'PAYROLL AUDIT']);
exports.handler = async function(event) {
  const headers = {'Content-Type':'application/json'};
  if (event.httpMethod !== 'POST') return {statusCode:405,headers,body:JSON.stringify({ok:false,error:'Method not allowed'})};
  try {
    const supabaseUrl = process.env.SUPABASE_URL;
    const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
    const sheetsUrl = process.env.GOOGLE_SHEETS_SYNC_URL;
    const sheetsSecret = process.env.GOOGLE_SHEETS_SYNC_SECRET;
    if (!supabaseUrl || !serviceKey || !sheetsUrl || !sheetsSecret) throw new Error('Google Sheets sync is not configured in Netlify environment variables.');
    const auth = event.headers.authorization || event.headers.Authorization || '';
    const match = auth.match(/^Bearer\s+(.+)$/i);
    if (!match) return {statusCode:401,headers,body:JSON.stringify({ok:false,error:'Sign-in required'})};
    const userResp = await fetch(supabaseUrl.replace(/\/$/, '') + '/auth/v1/user', {headers:{apikey:serviceKey,Authorization:'Bearer '+match[1]}});
    if (!userResp.ok) return {statusCode:401,headers,body:JSON.stringify({ok:false,error:'Payroll session is invalid or expired'})};
    const user = await userResp.json();
    if (String(user.email || '').toLowerCase() !== OWNER_EMAIL) return {statusCode:403,headers,body:JSON.stringify({ok:false,error:'Owner access required'})};
    const payload = JSON.parse(event.body || '{}');
    if (payload.action !== 'upsert' || !ALLOWED_SHEETS.has(String(payload.sheet || ''))) return {statusCode:400,headers,body:JSON.stringify({ok:false,error:'Unsupported action or sheet'})};
    const record = payload.record;
    if (!record || typeof record !== 'object' || Array.isArray(record) || Object.keys(record).length > 60) return {statusCode:400,headers,body:JSON.stringify({ok:false,error:'Invalid record'})};
    const resp = await fetch(sheetsUrl, {method:'POST',headers:{'Content-Type':'text/plain;charset=utf-8'},body:JSON.stringify({secret:sheetsSecret,action:'upsert',sheet:payload.sheet,record})});
    let result = {};
    try { result = await resp.json(); } catch (_) {}
    if (!resp.ok || result.ok !== true) throw new Error(result.error || ('Google Sheets returned HTTP '+resp.status));
    return {statusCode:200,headers,body:JSON.stringify({ok:true,sheet:result.sheet,row:result.row})};
  } catch (err) {
    console.error('sync-google-sheet error:', err);
    return {statusCode:500,headers,body:JSON.stringify({ok:false,error:String(err && err.message || err)})};
  }
};
