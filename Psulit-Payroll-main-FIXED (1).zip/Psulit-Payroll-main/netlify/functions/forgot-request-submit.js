// netlify/functions/forgot-request-submit.js
//
// Called by forgot-request.html when an employee submits a forgot-to-time-
// in/out request. Records it, sends you a Telegram approval message, and —
// if this employee has now submitted 3 or more of these requests all-time —
// also sends a warning to both you and the employee.
//
// Required Netlify environment variables (same as the other functions):
//   SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, TELEGRAM_BOT_TOKEN, SUPERVISOR_CHAT_ID

// Employee name -> Telegram Chat ID, for sending them their own 3-strike warning.
// Keep this in sync with the Employees tab in the Payroll app.
const EMPLOYEE_CHAT_IDS = {
  'Irene Maligat': '5582524994',
  'Angelica Besid': '329576744',
  'Cristina Mirang': '601568327',
  'Joan Legaspi': '6274133553',
  'Jazelle Espiritu': '6196732232'
};

exports.handler = async function (event) {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }

  let pin, action, date, time, reason;
  try {
    const body = JSON.parse(event.body || '{}');
    pin = body.pin;
    action = body.action;
    date = body.date;
    time = body.time;
    reason = (body.reason || '').trim();
    if (!pin || !action || !date || !time || !reason) throw new Error('Missing required fields');
  } catch (err) {
    return { statusCode: 400, body: JSON.stringify({ error: 'Missing or invalid fields' }) };
  }

  const SUPABASE_URL = process.env.SUPABASE_URL;
  const SERVICE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
  const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
  const SUPERVISOR_CHAT_ID = process.env.SUPERVISOR_CHAT_ID;

  try {
    const rpcResp = await fetch(`${SUPABASE_URL}/rest/v1/rpc/submit_forgot_request`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'apikey': SERVICE_KEY,
        'Authorization': `Bearer ${SERVICE_KEY}`
      },
      body: JSON.stringify({ input_pin: pin, input_action: action, input_date: date, input_time: time, input_reason: reason })
    });

    if (!rpcResp.ok) {
      const errText = await rpcResp.text();
      throw new Error(errText || 'Could not submit request');
    }

    const rows = await rpcResp.json();
    const row = Array.isArray(rows) ? rows[0] : rows;
    if (!row) throw new Error('No response from submit_forgot_request');

    const { id, employee_name, action: reqAction, request_date, request_time, reason: reqReason, total_count } = row;
    const actionLabel = reqAction === 'in' ? 'Time In' : 'Time Out';
    const dateLabel = new Date(request_date + 'T00:00:00').toLocaleDateString('en-PH', {
      month: 'long', day: 'numeric', year: 'numeric'
    });
    const timeLabel = request_time
      ? new Date(request_date + 'T' + request_time).toLocaleTimeString('en-PH', { hour: 'numeric', minute: '2-digit' })
      : null;

    async function sendTelegram(chatId, text, withButtons) {
      if (!chatId) return;
      const payload = { chat_id: chatId, text, parse_mode: 'Markdown' };
      if (withButtons) {
        payload.reply_markup = {
          inline_keyboard: [[
            { text: '\u2705 Approve', callback_data: `fapprove:${id}` },
            { text: '\u274C Decline', callback_data: `fdecline:${id}` }
          ]]
        };
      }
      await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
    }

    const mainMessage =
      `\u23F0 *Forgot ${actionLabel} Request*\n\n` +
      `${employee_name} says they forgot to ${actionLabel.toLowerCase()} on ${dateLabel}` +
      (timeLabel ? ` at ${timeLabel}` : '') + `\n` +
      `Reason: ${reqReason}`;

    await sendTelegram(SUPERVISOR_CHAT_ID, mainMessage, true);

    if (total_count >= 3) {
      const warningForSupervisor =
        `\u26A0\uFE0F *${employee_name} has submitted ${total_count} \u201cforgot to time in/out\u201d requests all-time.*`;
      const warningForEmployee =
        `\u26A0\uFE0F Hi ${employee_name}, this is your ${total_count}${total_count === 3 ? 'rd' : 'th'} \u201cforgot to time in/out\u201d request. Please try to remember to tap in and out at the kiosk going forward.`;
      await sendTelegram(SUPERVISOR_CHAT_ID, warningForSupervisor, false);
      await sendTelegram(EMPLOYEE_CHAT_IDS[employee_name], warningForEmployee, false);
    }

    return { statusCode: 200, body: JSON.stringify({ status: 'submitted' }) };
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
  }
};
