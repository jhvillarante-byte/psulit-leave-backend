// netlify/functions/get-employees-sheet.js
//
// Reads a Google Sheet's values using a service account, so the sheet can stay
// completely private (shared only with the service account's email, never
// published publicly). No npm dependencies -- builds and signs the JWT by hand
// using Node's built-in crypto module.
//
// Setup: in the Netlify site dashboard, go to
// Site configuration > Environment variables > Add two variables:
//   GOOGLE_SERVICE_ACCOUNT_EMAIL   -> the service account's email address
//   GOOGLE_SERVICE_ACCOUNT_KEY     -> the service account's private key (the
//                                      full "private_key" field from the JSON
//                                      key file, including the BEGIN/END lines)
//
// See SETUP_INSTRUCTIONS.md for how to create the service account and share
// your sheet with it.

const crypto = require('crypto');

function base64url(input) {
  return Buffer.from(input)
    .toString('base64')
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/, '');
}

async function getAccessToken() {
  const email = process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL;
  const rawKey = process.env.GOOGLE_SERVICE_ACCOUNT_KEY;
  if (!email || !rawKey) {
    throw new Error('GOOGLE_SERVICE_ACCOUNT_EMAIL / GOOGLE_SERVICE_ACCOUNT_KEY are not set on the server. Add them under Site configuration > Environment variables in Netlify, then redeploy.');
  }
  const privateKey = rawKey.replace(/\\n/g, '\n');

  const now = Math.floor(Date.now() / 1000);
  const header = { alg: 'RS256', typ: 'JWT' };
  const claim = {
    iss: email,
    scope: 'https://www.googleapis.com/auth/spreadsheets.readonly',
    aud: 'https://oauth2.googleapis.com/token',
    exp: now + 3600,
    iat: now
  };
  const unsigned = base64url(JSON.stringify(header)) + '.' + base64url(JSON.stringify(claim));

  const signer = crypto.createSign('RSA-SHA256');
  signer.update(unsigned);
  signer.end();
  const signature = signer.sign(privateKey)
    .toString('base64')
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/, '');

  const jwt = unsigned + '.' + signature;

  const resp = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer',
      assertion: jwt
    })
  });
  const data = await resp.json();
  if (!data.access_token) {
    throw new Error('Could not get access token from Google: ' + (data.error_description || JSON.stringify(data)));
  }
  return data.access_token;
}

exports.handler = async function (event) {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: JSON.stringify({ error: 'Method not allowed' }) };
  }

  try {
    const { sheetId, range } = JSON.parse(event.body || '{}');
    if (!sheetId) throw new Error('Missing sheetId in request body.');

    const token = await getAccessToken();
    const encodedRange = encodeURIComponent(range || 'A:Z');

    const resp = await fetch(
      `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${encodedRange}`,
      { headers: { Authorization: 'Bearer ' + token } }
    );
    const data = await resp.json();
    if (!resp.ok) {
      throw new Error(data.error && data.error.message ? data.error.message : 'Google Sheets API returned an error.');
    }

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ values: data.values || [] })
    };
  } catch (err) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: err.message })
    };
  }
};
