// Netlify Function: send-schedule
// Posts the branded weekly schedule image to a Telegram group chat.
// Set these two environment variables in Netlify (Site configuration > Environment variables):
//   SCHEDULE_BOT_TOKEN     — the Telegram bot token to send with
//   SCHEDULE_GROUP_CHAT_ID — the target group's chat ID (defaults to -5135138624 below)

exports.handler = async function (event) {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: JSON.stringify({ error: 'Method not allowed' }) };
  }

  const BOT_TOKEN = process.env.SCHEDULE_BOT_TOKEN;
  const CHAT_ID = process.env.SCHEDULE_GROUP_CHAT_ID || '-5135138624';

  if (!BOT_TOKEN) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Missing SCHEDULE_BOT_TOKEN environment variable in Netlify.' })
    };
  }

  try {
    const { imageBase64, caption, message } = JSON.parse(event.body || '{}');

    // Prefer sending the branded image (sendPhoto); fall back to plain text if
    // no image was provided for some reason.
    if (imageBase64) {
      const buffer = Buffer.from(imageBase64, 'base64');
      const form = new FormData();
      form.append('chat_id', CHAT_ID);
      if (caption) form.append('caption', caption);
      form.append('photo', new Blob([buffer], { type: 'image/png' }), 'schedule.png');

      const resp = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendPhoto`, {
        method: 'POST',
        body: form
      });
      const data = await resp.json();
      if (!data.ok) {
        return { statusCode: 502, body: JSON.stringify({ error: data.description || 'Telegram send failed' }) };
      }
      return { statusCode: 200, body: JSON.stringify({ ok: true }) };
    }

    if (message) {
      const resp = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chat_id: CHAT_ID, text: message })
      });
      const data = await resp.json();
      if (!data.ok) {
        return { statusCode: 502, body: JSON.stringify({ error: data.description || 'Telegram send failed' }) };
      }
      return { statusCode: 200, body: JSON.stringify({ ok: true }) };
    }

    return { statusCode: 400, body: JSON.stringify({ error: 'Missing imageBase64 or message' }) };
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
  }
};
