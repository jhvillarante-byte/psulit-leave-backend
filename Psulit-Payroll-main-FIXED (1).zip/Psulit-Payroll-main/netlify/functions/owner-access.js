// Server-side owner PIN verification for PSulit Payroll.
// The PIN and Supabase service-role key are read only from Netlify secrets.
const crypto = require('crypto');

const OWNER_EMAIL = 'jhvillarante@gmail.com';

function json(statusCode, payload) {
  return {
    statusCode,
    headers: {
      'Content-Type': 'application/json',
      'Cache-Control': 'no-store',
      'X-Content-Type-Options': 'nosniff'
    },
    body: JSON.stringify(payload)
  };
}

exports.handler = async function (event) {
  if (event.httpMethod !== 'POST') return json(405, { error: 'Method not allowed.' });

  const pinSecret = process.env.PAYROLL_ADMIN_PIN;
  const supabaseUrl = process.env.SUPABASE_URL;
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!pinSecret || !supabaseUrl || !serviceKey) {
    return json(503, { error: 'Owner login is not configured. Contact the administrator.' });
  }

  let body;
  try { body = JSON.parse(event.body || '{}'); }
  catch (_) { return json(400, { error: 'Invalid request.' }); }

  const pin = String(body.pin || '');
  const expected = Buffer.from(pinSecret, 'utf8');
  const supplied = Buffer.from(pin, 'utf8');
  const pinMatches = /^\d{4}$/.test(pin) &&
    expected.length === supplied.length &&
    crypto.timingSafeEqual(expected, supplied);

  const ip = (event.headers && (event.headers['x-nf-client-connection-ip'] ||
    event.headers['x-forwarded-for'])) || 'unknown';
  const ipHash = crypto.createHash('sha256').update(String(ip).split(',')[0].trim() + ':' + serviceKey).digest('hex');

  try {
    const rpc = await fetch(supabaseUrl.replace(/\/$/, '') + '/rest/v1/rpc/owner_pin_attempt', {
      method: 'POST',
      headers: {
        'apikey': serviceKey,
        'Authorization': 'Bearer ' + serviceKey,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ p_ip_hash: ipHash, p_action: 'check' })
    });
    if (!rpc.ok) throw new Error('Rate-limit check failed');
    const rate = await rpc.json();
    if (!rate.allowed) return json(429, { error: 'Too many incorrect PIN attempts. Please try again in 15 minutes.' });

    if (!pinMatches) {
      const fail = await fetch(supabaseUrl.replace(/\/$/, '') + '/rest/v1/rpc/owner_pin_attempt', {
        method: 'POST',
        headers: {
          'apikey': serviceKey,
          'Authorization': 'Bearer ' + serviceKey,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ p_ip_hash: ipHash, p_action: 'fail' })
      });
      if (!fail.ok) throw new Error('Failed to record PIN attempt');
      const failureState = await fail.json();
      if (!failureState.allowed) return json(429, { error: 'Too many incorrect PIN attempts. Please try again in 15 minutes.' });
      return json(401, { error: 'Incorrect PIN. Please try again.' });
    }

    const reset = await fetch(supabaseUrl.replace(/\/$/, '') + '/rest/v1/rpc/owner_pin_attempt', {
      method: 'POST',
      headers: {
        'apikey': serviceKey,
        'Authorization': 'Bearer ' + serviceKey,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ p_ip_hash: ipHash, p_action: 'success' })
    });
    if (!reset.ok) throw new Error('Could not reset PIN attempt counter');

    const linkResponse = await fetch(supabaseUrl.replace(/\/$/, '') + '/auth/v1/admin/generate_link', {
      method: 'POST',
      headers: {
        'apikey': serviceKey,
        'Authorization': 'Bearer ' + serviceKey,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ type: 'magiclink', email: OWNER_EMAIL })
    });
    const linkData = await linkResponse.json().catch(() => ({}));
    if (!linkResponse.ok) throw new Error('Owner session could not be created');
    // The raw Auth REST endpoint returns hashed_token at the top level.
    // The Supabase JS SDK wraps this under data.properties, but this is a direct REST call.
    const tokenHash = linkData && (linkData.hashed_token ||
      (linkData.properties && linkData.properties.hashed_token));
    if (!tokenHash) throw new Error('Owner session token was not returned');
    return json(200, { token_hash: tokenHash });
  } catch (error) {
    console.error('Owner access error:', error && error.message);
    return json(503, { error: 'Owner login is temporarily unavailable. Please try again.' });
  }
};
