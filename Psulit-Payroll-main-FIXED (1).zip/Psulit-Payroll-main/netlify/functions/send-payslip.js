// netlify/functions/send-payslip.js
//
// Sends a payslip PDF as a Telegram document message using the Telegram Bot API.
// Builds the multipart/form-data request manually with Buffers only (no FormData/Blob),
// since those globals aren't reliably available across all Netlify Functions runtimes.
//
// Setup: in the Netlify site dashboard, go to
// Site configuration > Environment variables > Add a variable
// Key:   TELEGRAM_BOT_TOKEN
// Value: (the token @BotFather gave you when you created the bot, looks like
//         123456789:AAExampleTokenStringHere)
//
// Each employee needs to have messaged your bot at least once (Telegram
// requires this before a bot can message someone) -- see SETUP_INSTRUCTIONS.md
// for how to find their numeric Chat ID afterward.

exports.handler = async function (event) {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: JSON.stringify({ error: 'Method not allowed' }) };
  }

  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'TELEGRAM_BOT_TOKEN is not set on the server. Add it under Site configuration > Environment variables in Netlify, then redeploy.' })
    };
  }

  try {
    const { chatId, filename, pdfBase64, message } = JSON.parse(event.body || '{}');
    if (!chatId || !pdfBase64) {
      throw new Error('Missing chatId or pdfBase64 in request body.');
    }
    const fileBuffer = Buffer.from(pdfBase64, 'base64');
    const safeFilename = filename || 'payslip.pdf';

    // Manually build a multipart/form-data body using only Buffers.
    const boundary = 'NetlifyFormBoundary' + Math.random().toString(16).slice(2);
    const CRLF = '\r\n';
    const parts = [];

    parts.push(Buffer.from(
      `--${boundary}${CRLF}Content-Disposition: form-data; name="chat_id"${CRLF}${CRLF}${chatId}${CRLF}`
    ));

    if (message) {
      parts.push(Buffer.from(
        `--${boundary}${CRLF}Content-Disposition: form-data; name="caption"${CRLF}${CRLF}${message}${CRLF}`
      ));
    }

    parts.push(Buffer.from(
      `--${boundary}${CRLF}Content-Disposition: form-data; name="document"; filename="${safeFilename}"${CRLF}Content-Type: application/pdf${CRLF}${CRLF}`
    ));
    parts.push(fileBuffer);
    parts.push(Buffer.from(`${CRLF}--${boundary}--${CRLF}`));

    const body = Buffer.concat(parts);

    const resp = await fetch('https://api.telegram.org/bot' + token + '/sendDocument', {
      method: 'POST',
      headers: {
        'Content-Type': `multipart/form-data; boundary=${boundary}`,
        'Content-Length': String(body.length)
      },
      body
    });

    const text = await resp.text();
    let data;
    try { data = JSON.parse(text); } catch (e) { data = null; }

    if (!data || !data.ok) {
      throw new Error('Telegram API: ' + (data && data.description ? data.description : text.slice(0, 300)));
    }

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ok: true })
    };
  } catch (err) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: err.message })
    };
  }
};
