// netlify/functions/telegram-webhook.js
//
// Receives Telegram's callback when you tap Approve or Decline.
// Handles two kinds of requests, distinguished by the callback_data prefix:
//   approve/decline   - normal kiosk Time In/Out requests (writes to time_logs
//                        via the unchanged complete_kiosk_request function)
//   fapprove/fdecline - "forgot to time in/out" requests (writes directly to
//                        the Psulit Time Logs Google Sheet on approval)
//
// One-time setup after deploying this: tell Telegram where to send button
// taps by visiting this URL once in your browser (replace the placeholders):
//
//   https://api.telegram.org/bot<TELEGRAM_BOT_TOKEN>/setWebhook?url=https://psulitpayroll.netlify.app/.netlify/functions/telegram-webhook
//
// Required Netlify environment variables:
//   SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, TELEGRAM_BOT_TOKEN,
//   SHEETS_LOG_URL, SHEETS_LOG_SECRET

exports.handler = async function (event) {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }

  const SUPABASE_URL = process.env.SUPABASE_URL;
  const SERVICE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
  const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
  const SHEETS_LOG_URL = process.env.SHEETS_LOG_URL;
  const SHEETS_LOG_SECRET = process.env.SHEETS_LOG_SECRET;

  let update;
  try {
    update = JSON.parse(event.body || '{}');
  } catch (err) {
    return { statusCode: 400, body: 'Invalid payload' };
  }

  const callback = update.callback_query;
  if (!callback) {
    // Not a button tap (could be a plain message) - nothing to do, but
    // still return 200 so Telegram doesn't keep retrying.
    return { statusCode: 200, body: 'OK' };
  }

  const data = callback.data || '';
  const [decision, idOrToken] = data.split(':');
  const chatId = callback.message.chat.id;
  const messageId = callback.message.message_id;
  const originalText = callback.message.text || '';

  async function callRpc(fnName, body) {
    const resp = await fetch(`${SUPABASE_URL}/rest/v1/rpc/${fnName}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'apikey': SERVICE_KEY,
        'Authorization': `Bearer ${SERVICE_KEY}`
      },
      body: JSON.stringify(body)
    });
    if (!resp.ok) {
      const errText = await resp.text();
      throw new Error(errText || `${fnName} failed`);
    }
    const rows = await resp.json();
    return Array.isArray(rows) ? rows[0] : rows;
  }

  async function postToGoogleSheet(name, action, timestampIso) {
    if (!SHEETS_LOG_URL || !SHEETS_LOG_SECRET) return; // not configured, skip silently
    await fetch(SHEETS_LOG_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      body: JSON.stringify({
        secret: SHEETS_LOG_SECRET,
        sheet: 'Time Logs',
        name, action, timestamp: timestampIso
      })
    });
  }

  async function answerCallback(text) {
    await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/answerCallbackQuery`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ callback_query_id: callback.id, text })
    });
  }

  async function editMessage(newText) {
    await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/editMessageText`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: chatId,
        message_id: messageId,
        text: newText,
        parse_mode: 'Markdown'
      })
    });
  }

  try {
    if (decision === 'approve') {
      await callRpc('complete_kiosk_request', { input_token: idOrToken });
      await answerCallback('Approved');
      await editMessage(originalText + '\n\n\u2705 *Approved* \u2014 posted to the sheet.');
    } else if (decision === 'decline') {
      await callRpc('decline_kiosk_request', { input_token: idOrToken });
      await answerCallback('Declined');
      await editMessage(originalText + '\n\n\u274C *Declined* \u2014 not recorded.');
    } else if (decision === 'fapprove') {
      const req = await callRpc('resolve_forgot_request', { input_id: Number(idOrToken), input_status: 'completed' });
      // Only a date was captured, not a time - combine the requested date
      // with the current moment's time-of-day so the sheet's IN/OUT column
      // gets a real timestamp to fill the blank cell with.
      const now = new Date();
      const combined = new Date(req.request_date + 'T00:00:00');
      combined.setHours(now.getHours(), now.getMinutes(), now.getSeconds());
      await postToGoogleSheet(req.employee_name, req.action, combined.toISOString());
      await answerCallback('Approved');
      await editMessage(originalText + '\n\n\u2705 *Approved* \u2014 posted to the Time Logs sheet.');
    } else if (decision === 'fdecline') {
      await callRpc('resolve_forgot_request', { input_id: Number(idOrToken), input_status: 'declined' });
      await answerCallback('Declined');
      await editMessage(originalText + '\n\n\u274C *Declined* \u2014 not recorded.');
    } else {
      await answerCallback('Unrecognized action');
    }
  } catch (err) {
    await answerCallback('Error: ' + err.message);
    await editMessage(originalText + '\n\n\u26A0\uFE0F Could not process: ' + err.message);
  }

  return { statusCode: 200, body: 'OK' };
};

